import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';

const ADMIN_EMAILS = [
  "tcincy23@gmail.com",
  "sinsinnatikeyconnection@gmail.com",
];

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const lat = Number(body.latitude);
    const lon = Number(body.longitude);
    if (!Number.isFinite(lat) || !Number.isFinite(lon)) {