// Creates (or returns an existing) unpaid Invoice for a per-VIN premium
// diagnostic unlock. Public app — customers are not logged in, so the unlock is
// keyed by their email. Service-role creates the invoice (RLS create is admin-only).
// Idempotent: an existing unpaid invoice for the same email+VIN is reused instead
// of creating a duplicate — the client then calls `create-checkout` to open payment.

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { waitUntil } from 'base44:runtime';
import { logFault } from "../../shared/logFault.ts";
import { notifyCustomer } from "../../shared/notify.ts";

const VIN_RE = /^[A-HJ-NPR-Z0-9]{17}$/;
const PRICE = 25.00;
const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;