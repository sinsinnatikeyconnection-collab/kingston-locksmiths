import React, { useState, useEffect } from "react";
import { Phone, X } from "lucide-react";

interface PhoneLine {
  label: string;
  value: string;
  tel: string;
}

const NUMBERS: PhoneLine[] = [
  { label: "Primary", value: "513-568-2744", tel: "+15135682744" },
  { label: "Secondary", value: "812-571-5765", tel: "+18125715765" },
];