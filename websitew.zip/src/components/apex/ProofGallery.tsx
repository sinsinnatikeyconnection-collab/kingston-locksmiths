import React, { useState, useEffect } from "react";
import { Image } from "@/components/ui/image";
import { ChevronRight } from "lucide-react";

interface CaseStudyItem {
  id?: string;
  image_url: string;
  side: "Digital" | "Physical";
  title: string;
  tag?: string;
  order?: number;
}