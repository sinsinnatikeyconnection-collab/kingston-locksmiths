import React, { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Calculator, ChevronRight, Info } from "lucide-react";
import { PRICING, URGENCIES, estimate, type UrgencyId } from "@/lib/pricing";

export default function PriceEstimator() {
  const [pillarId, setPillarId] = useState(PRICING[0].id);
  const pillar = useMemo(() => PRICING.find((p) => p.id === pillarId)!, [pillarId]);
  const [subName, setSubName] = useState<string>(pillar.sub[0]?.name ?? "");
  const [urgencyId, setUrgencyId] = useState<UrgencyId>("standard");
  const [year, setYear] = useState<string>("");
  const [make, setMake] = useState<string>("");

  // keep subservice valid when pillar changes