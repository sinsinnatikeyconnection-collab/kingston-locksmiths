import React, { useState, useEffect, useRef, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { Accessibility, Mic, MicOff, CalendarClock, X, Type, Volume2 } from "lucide-react";

type Nav = (to: string) => void;

export default function UniversalAccess() {
  const [open, setOpen] = useState(false);
  const [largeText, setLargeText] = useState(false);
  const [listening, setListening] = useState(false);
  const [heard, setHeard] = useState("");
  const [unsupported, setUnsupported] = useState(false);
  const recRef = useRef<any>(null);
  const navigate = useNavigate() as Nav;