import React from "react";
import Navbar from "@/components/apex/Navbar";
import Footer from "@/components/apex/Footer";
import FloatingCall from "@/components/apex/FloatingCall";

interface PageShellProps {
  children: React.ReactNode;
  title?: string;
  tagline?: string;
}

export default function PageShell({ children, title, tagline }: PageShellProps) {
  return (
    <div className="bg-titanium min-h-screen">