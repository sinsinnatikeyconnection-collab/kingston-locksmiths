import React from "react";
import { Link } from "react-router-dom";
import { Image } from "@/components/ui/image";
import { ChevronRight, ChevronLeft, Cpu, AlertTriangle, Workflow, Wrench } from "lucide-react";
import { PILLARS } from "@/lib/servicesData";

const accentColor = (a: string) => (a === "heat" ? "heat" : a === "data" ? "data" : "cyan");

// Shared deep-breakdown renderer used by the four dedicated pillar pages.
export default function PillarDetail({ id, afterCapabilities }: { id: string; afterCapabilities?: React.ReactNode }) {
  const p = PILLARS.find((x) => x.id === id);
  if (!p) return null;
  const ac = accentColor(p.accent);
  const idx = PILLARS.findIndex((x) => x.id === id);