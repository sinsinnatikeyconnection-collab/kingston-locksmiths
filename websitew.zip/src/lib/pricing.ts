export interface SubPrice {
  name: string;
  low: number;
  high: number;
}

export interface PillarPrice {
  id: string;
  label: string;
  diagnostic: [number, number];
  sub: SubPrice[];
}

// Representative LABOR ranges (USD). Parts, programming credits, and shipping are