
export type HealthSeverity = "info" | "warning" | "error" | "critical";

export interface SystemHealthLogEntry {
  code: string;
  message: string;
  stack?: string;
  component: string;
  action?: string;
  severity?: HealthSeverity;
}

// Best-effort, deduped client-side error reporter. Repeated identical faults