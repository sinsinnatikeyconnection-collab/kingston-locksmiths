import { useState, useEffect, useRef } from "react";

// Reusable shape of a decoded VIN — mirrors the `decodeVin` backend function's
// response so the intake form and the engine diagnostic use one source of truth.
export interface VinRecall {
  number: string;
  date: string;
  component: string;
  summary: string;
  consequence: string;
  remedy: string;
}